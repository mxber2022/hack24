"use client"

function Nav() {
    return(
        <>
            <w3m-button />
        </>
    )
}

export default Nav;